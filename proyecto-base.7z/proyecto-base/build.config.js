/**
 * This file/module contains all configuration for the build process.
 */
module.exports = {
    /**
     * The `build_dir` folder is where our projects are compiled during
     * development and the `compile_dir` folder is where our app resides once it's
     * completely built.
     */
    build_dir: 'build',
    compile_dir: 'bin',
    src_dir: 'src',
    sonar_tmp_dir: '.tmp',
    karma_reports: 'reports',
    build_zip: 'build.zip',
    bin_zip: 'bin.zip',

    /**
     * This is a collection of file patterns that refer to our app code (the
     * stuff in `src/`). These file paths are used in the configuration of
     * build tasks. `js` is all project javascript, less tests. `common_tpl` contains
     * our reusable components' (`src/common`) template HTML files, while
     * `app_tpl` contains the same, but for our app's code. `html` is just our
     * main HTML file, `less` is our main stylesheet, and `unit` contains our
     * app's unit tests.
     */
    app_files: {
        modjs: ['src/**/*_module.js'],
        configjs: ['src/**/*_config.js'],
        js: [
            'src/**/*.js',
            '!src/**/*_test.js',
            '!src/assets/**/*.js',
            '!src/assets/**/*_config.js',
            '!src/assets/**/*_module.js'
        ],
        jsunit: ['src/**/*_test.js'],

        app_tpl: ['src/app/**/*_tpl.html'],
        orion_tpl: ['vendor/orion-*/**/*.tpl.html'],
        taurus_tpl: ['vendor/taurus-*/**/*_tpl.html'],
        common_tpl: ['src/common/**/*_tpl.html'],
        taurus_files: ['vendor/taurus-*/src/app/**/*.js', 'vendor/taurus-*/**/*.html'],

        html: ['src/index.html'],
        less: 'src/less/main.less',
        stylus_folder: 'src/stylus/',
        stylus_component_folder: 'src/app/components/**/',
        stylus_vendor_orion_folders: 'vendor/orion-*/stylus/',
        stylus_vendor_taurus_folders: 'vendor/taurus-*/**/stylus/',
        stylus_style_guide: 'vendor/taurus-style-guide/src/stylus/',
        taurus_header: 'vendor/taurus-header/src/app/components/header/'

    },

    /**
     * This is a collection of files used during testing only.
     */
    test_files: {
        js: [
            'vendor/angular-mocks/angular-mocks.js'
        ]
    },

    /**
     * This is the same as `app_files`, except it contains patterns that
     * reference vendor code (`vendor/`) that we need to place into the build
     * process somewhere. While the `app_files` property ensures all
     * standardized files are collected for compilation, it is the user's job
     * to ensure non-standardized (i.e. vendor-related) files are handled
     * appropriately in `vendor_files.js`.
     *
     * The `vendor_files.js` property holds files to be automatically
     * concatenated and minified with our project source files.
     *
     * The `vendor_files.css` property holds any CSS files to be automatically
     * included in our app.
     *
     * The `vendor_files.assets` property holds any assets to be copied along
     * with our app's assets. This structure is flattened, so it is not
     * recommended that you use wildcards.
     */
    vendor_files: {
        js: [
            'vendor/jquery/dist/jquery.js',
            'vendor/angular/angular.js',
            'vendor/angular-local-storage/dist/angular-local-storage.js',
            'vendor/angular-loading-bar/build/loading-bar.min.js',
            'vendor/angular-input-masks/angular-input-masks-standalone.js',
            'vendor/angular-toastr/dist/angular-toastr.tpls.js',
            'vendor/angular-float-thead/angular-floatThead.js',
            'vendor/angular-sweetalert/SweetAlert.js',
            'vendor/angular-bootstrap/ui-bootstrap-tpls.min.js',
            'vendor/angular-ui-router/release/angular-ui-router.js',
            'vendor/angular-ui-router/release/stateEvents.js',
            'vendor/angular-ui-utils/modules/route/route.js',
            'vendor/angular-file-upload/angular-file-upload.js',
            'vendor/angular-i18n/angular-locale_es-cl.js',
            'vendor/angular-messages/angular-messages.js',
            'vendor/angular-rut/dist/angular-rut.js',
            'vendor/angular-ui-utils/ui-utils.js',
            'vendor/angular-sanitize/angular-sanitize.js',
            'vendor/angular-xeditable/dist/js/xeditable.js',
            'vendor/angular-tablesort/js/angular-tablesort.js',
            'vendor/angular-resource/angular-resource.js',
            'vendor/angular-ui-select/dist/select.js',
            'vendor/angular-animate/angular-animate.js',
            'vendor/angular-rangeslider/angular.rangeSlider.js',
            'vendor/angular-ladda/dist/angular-ladda.min.js',
            'vendor/angular-progress-button-styles/dist/angular-progress-button-styles.min.js',
            'vendor/angular-ui-grid/ui-grid.js',
            'vendor/clockpicker/dist/bootstrap-clockpicker.js',
            'vendor/clockpicker/dist/jquery-clockpicker.js',
            'vendor/modernizr/modernizr.js',
            'vendor/lodash/dist/lodash.js',
            'vendor/orion-*/**/*.module.js',
            'vendor/orion-*/**/*.js',
            'vendor/ladda/js/spin.js',
            'vendor/file-saver.js/FileSaver.js',
            'vendor/ladda/js/ladda.js',
            'vendor/ng-scrollbar/dist/ng-scrollbar.js',
            'vendor/ng-caps-lock/ng-caps-lock.js',
            'vendor/highcharts/highcharts.src.js',
            'vendor/highcharts-ng/dist/highcharts-ng.js',
            'vendor/sweetalert-ui/lib/sweet-alert.js',
            'vendor/floatThead/dist/jquery.floatThead.min.js',
            'vendor/ng-sticky-element/dist/ng-sticky-element.min.js',
            'vendor/moment/moment.js',
            'vendor/angular-translate/angular-translate.js',
            'vendor/angular-translate-loader-partial/angular-translate-loader-partial.js',
            'vendor/angular-off-click/dist/angular-off-click.js',
            'vendor/orion-directivas-tablas/src/orionTablas/directives/orionTablas.js',
            'vendor/orion-directivas-tablas/src/orionTablas/directives/orionTablaSelect.js',
            'vendor/orion-directivas-tablas/src/orionTablas/orionTablas.constants.js',
            'vendor/orion-bch-*/**/*.js',
            'vendor/orion-directive-*/**/*.js',
            'vendor/crypto-js/crypto-js.js',
			'vendor/ng-file-upload*/*.js',
            'vendor/angular-click-outside/clickoutside.directive.js',
            'vendor/pdfmake/build/pdfmake.js',
            'vendor/html2canvas/build/html2canvas.js',
            'vendor/angular-svg-round-progressbar/build/roundProgress.min.js',
            'vendor/bower-canvas2image/canvas2image/canvas2image.js'
        ],
        taurusjs: [
            //fixme no sigue nomenclatura
            //
            'vendor/bchui-*/dist/*.js',
            'vendor/taurus-directive-number/src/app/commons/ng-number_module.js',
            'vendor/taurus-directive-date/src/app/commons/directives/date_directive.js',
            'vendor/taurus-directive-enter/src/app/commons/directives/enter_directive.js',
            'vendor/taurus-directive-number/src/app/commons/directives/number_directive.js',
            'vendor/taurus-directive-only-alphabet-with-space/src/app/commons/directives/onlyString_directive.js',
            'vendor/taurus-directive-only-number/src/app/commons/directives/onlyNumber_directive.js',
            'vendor/taurus-directive-phone-number/src/app/commons/directives/phoneNumber_directive.js',
            'vendor/taurus-directive-rut/src/app/commons/directives/rut_directive.js',
            'vendor/taurus-directive-show-if-authorized/src/app/commons/directives/show-if-authorized_directive.js',
            'vendor/taurus-directive-validatekey/src/app/commons/directives/validatekey_directive.js',
            'vendor/taurus-format-number/src/app/commons/directives/formatnumber_directive.js',
            'vendor/taurus-paginator/src/app/commons/directives/paginator_directive.js',

            //Configuracion Proyectos Taurus
            'vendor/taurus-*/src/**/*module.js',
            'vendor/taurus-*/src/**/*config.js',
            'vendor/taurus-*/src/**/*factory.js',
            'vendor/taurus-*/src/**/*service.js',
            'vendor/taurus-*/src/**/*controller.js',
            'vendor/taurus-*/src/**/*filter.js',
            'vendor/taurus-*/src/**/*directive.js',
            'vendor/taurus-*/src/**/*constants.js',
            'vendor/taurus-filters/src/**/*.js'
        ],
        json: [
            'vendor/taurus-catalogos/src/**/*.json'
        ],
        css: [
            'vendor/bootstrap/dist/css/bootstrap.css',
            'vendor/angular-ui-select/dist/select.css',
            'vendor/ng-scrollbar/dist/ng-scrollbar.css',
            'vendor/ionicons/css/ionicons.css',
            'vendor/ladda/dist/ladda-themeless.min.css',
            'vendor/sweetalert-ui/lib/sweet-alert.css',
            'vendor/clockpicker/dist/bootstrap-clockpicker.css',
            'vendor/clockpicker/dist/jquery-clockpicker.css',
            'vendor/ng-sticky-element/dist/ng-sticky-element.min.css',
            'vendor/font-awesome/css/font-awesome.css',
            'vendor/angular-loading-bar/build/loading-bar.min.css',
            'vendor/angular-toastr/dist/angular-toastr.css',
            'vendor/angular-progress-button-styles/dist/angular-progress-button-styles.min.css',
            'vendor/angular-xeditable/dist/css/xeditable.css',
            'vendor/angular-ui-grid/ui-grid.css'
        ],
        assets: [
            'vendor/orion-*/assets/**',
            'src/assets/**'
        ],
        fonts: [
            'vendor/ionicons/fonts/ionicons.eot',
            'vendor/ionicons/fonts/ionicons.svg',
            'vendor/ionicons/fonts/ionicons.ttf',
            'vendor/ionicons/fonts/ionicons.woff',
            'vendor/orion-ui-grid/ui-grid.woff',
            'vendor/orion-ui-grid/ui-grid.ttf',
            'vendor/orion-ui-grid/ui-grid.svg',
            'vendor/font-awesome/fonts/fontawesome-webfont.eot',
            'vendor/font-awesome/fonts/fontawesome-webfont.svg',
            'vendor/font-awesome/fonts/fontawesome-webfont.ttf',
            'vendor/font-awesome/fonts/fontawesome-webfont.woff',
            'vendor/font-awesome/fonts/fontawesome-webfont.woff2',
            'vendor/bootstrap/fonts/glyphicons-halflings-regular.eot',
            'vendor/bootstrap/fonts/glyphicons-halflings-regular.svg',
            'vendor/bootstrap/fonts/glyphicons-halflings-regular.ttf',
            'vendor/bootstrap/fonts/glyphicons-halflings-regular.woff',
            'vendor/bootstrap/fonts/glyphicons-halflings-regular.woff2'
        ]
    }
};