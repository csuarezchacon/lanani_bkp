-----------------
- PROYECTO-BASE -
-----------------

>>> grunt minibuild:
	La tarea minibuild, permite tener disponible un compilador grunt más rápido para trabajar localmente.
	Su ejecución hace casi lo mismo que la tarea build, pero se quitaron algunas sub-tareas de ésta, como el tratamiento de css y del vendor.
	Al eliminar estas sub-tareas, se optimizó considerablemente el tiempo de compilación.
	El alcance de la tarea minibuild sólo compila html y js del directorio /src del proyecto que se abrió localmente.
	Para poder utilizar minibuild, es requisito ejecutar inicialmente, una sola vez, "grunt" o "grunt build", y posteriormente "npm start".

>>> grunt minibuild watch:
	La tarea minibuild se puede complementar con la tarea watch, que otorga la opción para que las próximas compilaciones se ejecuten automáticamente cada vez que se guardan cambios.